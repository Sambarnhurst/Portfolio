# Forge v4.0 — Clean Workspace

Open `index.html` for offline mode, or launch the included local server for direct disk editing.

## Layout
- **Learn**: milestone cubes and lesson navigator. Use **Details** to show the lesson inspector or **Hide list** to focus on 3D.
- **Notes**: full documentation editor. The quick formatting toolbar stays visible; **All tools** reveals the original Home, Insert, Layout, Review and File ribbons. **Info** opens document properties.
- **Code**: starts in **Cubes** view with your file tree and 3D map. Switch to **Editor** to work on code; double-click a file cube to edit. **Find** opens search/replace; **Files & tools** contains importing, creation and exporting.

The original 33 study milestones and documentation/coding tools are included. No study data is deleted or reset. Existing local storage remains keyed the same as v3. Use **More > Backup everything** in Learn and **Export project ZIP** in Code to preserve data. When opening from another browser or machine, import your saved backup.

**Local disk editing**: Run `Start_Code_Forge_Windows.bat` (Python 3.10+) or `Start_Code_Forge_Linux_Mac.sh` from the extracted folder. The source server is unchanged from v3 and remains restricted to the selected directory.
