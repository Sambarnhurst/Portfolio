#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
exec python3 forge_server.py --project "${1:-$PWD}"
