# Code Cube Forge — Milestone Study Index

These are original suggested study topics and exercises, not official provider course outlines.

## 01. Responsive Web Design
**Provider:** freeCodeCamp  
**Resource:** https://www.freecodecamp.org/learn/responsive-web-design-v9/

Create responsive websites and understand how the browser lays out pages.

### 1. HTML structure
HTML creates the meaning and outline of a web page through elements such as headings, paragraphs, links and forms.
**Exercise:** Build a semantic profile page with a header, main region and footer.

### 2. CSS selectors and box model
CSS chooses which elements to style and controls dimensions, margin, border and padding.
**Exercise:** Restyle the profile page with a consistent spacing scale.

### 3. Flexbox and Grid
Flexbox aligns content along an axis; CSS Grid organizes elements in rows and columns.
**Exercise:** Create a mobile-friendly card gallery using Grid.

### 4. Responsive layouts
Media queries and fluid dimensions let interfaces adapt to small and large screens.
**Exercise:** Test a page at narrow phone, tablet and desktop widths.

### 5. Accessible forms
Proper labels, readable contrast and keyboard navigation matter as much as appearance.
**Exercise:** Add a working validation-ready contact form.

### 6. Portfolio project
A published page shows applied knowledge beyond completion of lessons.
**Exercise:** Design and document a small responsive developer portfolio.

## 02. JavaScript
**Provider:** freeCodeCamp  
**Resource:** https://www.freecodecamp.org/learn/javascript-v9/

Understand the language that powers interactive web applications.

### 1. Variables and types
Variables store changing information. Strings, numbers, booleans, arrays and objects represent different values.
**Exercise:** Create a study-hours calculator.

### 2. Conditions and loops
Branches select behavior and loops repeat a procedure.
**Exercise:** Build a quiz that checks and scores multiple answers.

### 3. Functions and scope
Functions make logic reusable and scope controls where variables can be accessed.
**Exercise:** Refactor the quiz into small testable functions.

### 4. Arrays and objects
Model structured data as collections of objects; transform arrays with map, filter and reduce.
**Exercise:** Represent your milestone list in JavaScript.

### 5. DOM events
Event listeners connect code to user clicks, typing and other interactions.
**Exercise:** Add a progress button to a webpage.

### 6. Debugging and tests
Reproduce errors, inspect values, and test assumptions before changing code.
**Exercise:** Find and fix three intentionally introduced bugs.

## 03. Front-End Development Libraries
**Provider:** freeCodeCamp  
**Resource:** https://www.freecodecamp.org/learn/front-end-development-libraries-v9/

Build maintainable interactive interfaces using modern component patterns.

### 1. Component thinking
Break screens into reusable components with explicit inputs.
**Exercise:** Sketch the layout of a milestone tracker as components.

### 2. State and rendering
State represents changing information; UI should follow the underlying state.
**Exercise:** Create a counter and task completion toggle.

### 3. Forms and validation
Collect and validate user input before persisting it.
**Exercise:** Build an editable notes form.

### 4. Routing and composition
Organize multiple screens without duplicating layout logic.
**Exercise:** Add dashboard and milestone detail views.

### 5. Type systems and tooling
TypeScript and bundlers help catch some mistakes earlier.
**Exercise:** Type a milestone object and its status enum.

### 6. Capstone interface
Combine components, state and data into a coherent usable product.
**Exercise:** Publish a responsive progress-tracker prototype.

## 04. Python
**Provider:** freeCodeCamp  
**Resource:** https://www.freecodecamp.org/learn/python-v9/

Learn a practical language for automation, AI tools, and backend development.

### 1. Python syntax
Expressions, variables, strings and lists are Python building blocks.
**Exercise:** Write a simple hours-per-week planner.

### 2. Logic and iteration
if statements, for loops and while loops control program flow.
**Exercise:** Find overdue tasks in a list.

### 3. Functions and modules
Separate logic into named functions and import functionality from modules.
**Exercise:** Turn the planner into reusable functions.

### 4. Dictionaries and files
Dictionaries model records; JSON stores portable structured data.
**Exercise:** Save milestone progress to a JSON file.

### 5. Errors and testing
Exceptions handle failure; assertions check expected behavior.
**Exercise:** Add input validation and a small test suite.

### 6. Practical scripting
Python can automate repetitive file operations and reports.
**Exercise:** Build a script that summarizes weekly learning activity.

## 05. Relational Databases
**Provider:** freeCodeCamp  
**Resource:** https://www.freecodecamp.org/learn/relational-databases-v9/

Store structured records and use terminal, Git and SQL tools.

### 1. Terminal basics
Learn paths, listing files, executing programs and useful command-line patterns.
**Exercise:** Navigate and inspect a practice project directory.

### 2. Git version control
A commit records a project snapshot; branches isolate proposed changes.
**Exercise:** Initialize a practice repo and commit your tracker.

### 3. SQL queries
SELECT, WHERE, ORDER BY and JOIN retrieve targeted records.
**Exercise:** Query completed versus incomplete lessons.

### 4. Database design
Keys and relationships prevent unnecessary duplication.
**Exercise:** Model milestones, sections and progress tables.

### 5. Updates and transactions
INSERT, UPDATE and DELETE modify data; transactions protect consistency.
**Exercise:** Save a new note and update its milestone status.

### 6. Backup and restore
Persistent records need safe export and recovery routines.
**Exercise:** Export your sample database and verify a restore.

## 06. Back-End Development and APIs
**Provider:** freeCodeCamp  
**Resource:** https://www.freecodecamp.org/learn/back-end-development-and-apis-v9/

Create servers and APIs used by web apps and AI integrations.

### 1. HTTP fundamentals
Requests and responses transport data between clients and servers.
**Exercise:** Inspect a simple GET request and response.

### 2. Node and server setup
Node.js runs JavaScript on the server.
**Exercise:** Build a local server with a health-check endpoint.

### 3. API routes
Endpoints expose application operations through defined input and output.
**Exercise:** Add GET /milestones and POST /notes.

### 4. Validation and errors
Validate all input and return meaningful error codes.
**Exercise:** Reject malformed progress updates.

### 5. Persistence
Connect application endpoints to durable data storage.
**Exercise:** Save notes to a database or JSON data store.

### 6. Integration testing
Test both expected and error paths of endpoints.
**Exercise:** Write tests for create, read and update operations.

## 07. Certified Full-Stack Developer
**Provider:** freeCodeCamp  
**Resource:** https://www.freecodecamp.org/learn/full-stack-developer-v9/

Integrate frontend, backend, data and development practices.

### 1. System planning
Define users, data models, interfaces and success criteria before implementation.
**Exercise:** Write a one-page plan for a learning portal.

### 2. Frontend integration
Connect a responsive interface to server-provided data.
**Exercise:** Replace static sample milestones with API data.

### 3. Backend integration
Build validated endpoints that enforce business rules.
**Exercise:** Implement progress and note operations.

### 4. Authentication concepts
Learn sessions, access controls and why personal records need protection.
**Exercise:** Diagram a login flow without storing secrets in client code.

### 5. Tests and deployment
Use test suites, logs and release checklists to reduce regressions.
**Exercise:** Document a deployment and rollback plan.

### 6. Portfolio capstone
Demonstrate an end-to-end application and explain its tradeoffs.
**Exercise:** Publish a learning portal and short architecture README.

## 08. Foundational C# with Microsoft
**Provider:** freeCodeCamp  
**Resource:** https://www.freecodecamp.org/learn/foundational-c-sharp-with-microsoft/

Learn a statically typed language useful for software and game programming.

### 1. Basic C# syntax
Understand variables, data types and formatted output.
**Exercise:** Build a text-based character status readout.

### 2. Control flow
Use branching and loops to process conditions and collections.
**Exercise:** Create a simple turn-based combat loop.

### 3. Methods
Methods group behavior and accept parameters.
**Exercise:** Implement reusable damage and healing methods.

### 4. Collections
Arrays, lists and dictionaries manage many related objects.
**Exercise:** Model a game inventory in C#.

### 5. Errors and debugging
Use exceptions and a debugger to inspect misbehavior.
**Exercise:** Fix a broken inventory update.

### 6. Application practice
Combine pieces into a small complete console application.
**Exercise:** Ship a self-contained inventory prototype.

## 09. Algorithms and Data Structures
**Provider:** freeCodeCamp  
**Resource:** https://www.freecodecamp.org/learn/algorithms-and-data-structure/

Improve problem solving and efficient data handling.

### 1. Algorithm thinking
Convert vague goals into clear procedures with inputs and outputs.
**Exercise:** Describe and implement a milestone search algorithm.

### 2. Lists and sorting
Sorting and searching rearrange or locate records.
**Exercise:** Compare two ways to sort tasks by priority.

### 3. Dictionaries and sets
Hash-based collections support efficient lookups and uniqueness.
**Exercise:** Remove duplicates from a list of resources.

### 4. Recursion and traversal
Some problems are naturally described in smaller subproblems.
**Exercise:** Traverse a tree of phases, milestones and sections.

### 5. Complexity basics
Time and memory costs change with data size.
**Exercise:** Explain the difference between linear and quadratic scans.

### 6. Applied challenge
Use the right data structure for a realistic feature.
**Exercise:** Implement dependency-aware milestones.

## 10. Data Visualization
**Provider:** freeCodeCamp  
**Resource:** https://www.freecodecamp.org/learn/data-visualization/

Transform data into accurate interactive charts.

### 1. Data encoding
Decide which visual properties should represent values.
**Exercise:** Sketch a weekly-hours bar chart.

### 2. SVG and scales
SVG elements and scales map numbers to positions.
**Exercise:** Build a labeled bar chart.

### 3. D3 data joins
Bind records to visual marks and update them when data changes.
**Exercise:** Animate progress bars on new entries.

### 4. Charts and interaction
Tooltips and filtering support exploratory analysis.
**Exercise:** Add filtering by certification provider.

### 5. Accessibility
Labels and summaries make graphics usable and interpretable.
**Exercise:** Provide a text summary for every chart.

### 6. Project
Create a clear, verifiable learning progress dashboard.
**Exercise:** Plot monthly hours and completion counts.

## 11. Quality Assurance
**Provider:** freeCodeCamp  
**Resource:** https://www.freecodecamp.org/learn/quality-assurance/

Test software systematically to find regressions before users do.

### 1. Test strategy
Unit tests verify small functions; integration tests verify components working together.
**Exercise:** Draft a test plan for saved notes.

### 2. Assertions and fixtures
Tests require predictable starting data and expected outputs.
**Exercise:** Test completion percentage calculation.

### 3. API testing
Endpoint tests check status codes, payloads and invalid inputs.
**Exercise:** Write tests for milestone update requests.

### 4. Edge cases
Test empty data, duplicate entries, malformed inputs and large lists.
**Exercise:** Verify importing a partially invalid backup is rejected.

### 5. Regression workflow
Every fixed defect should gain a test that reproduces it.
**Exercise:** Document a bug and add a regression test.

### 6. CI concepts
Automated test runs on new changes catch mistakes early.
**Exercise:** Create a basic GitHub Actions test job.

## 12. Scientific Computing with Python
**Provider:** freeCodeCamp  
**Resource:** https://www.freecodecamp.org/learn/scientific-computing-with-python/

Practice writing precise computational Python programs.

### 1. String processing
Normalize, split and validate user-provided text.
**Exercise:** Parse a plain-text study log.

### 2. Data structures
Organize related values for reliable updates and transformations.
**Exercise:** Model milestones as dictionaries.

### 3. Functions and modules
Separate concerns and make code reusable.
**Exercise:** Extract a progress-calculation module.

### 4. File handling
Read and write data files with robust error handling.
**Exercise:** Import and export a CSV report.

### 5. Algorithms
Use looping, arithmetic and control flow to solve nontrivial tasks.
**Exercise:** Calculate a rolling seven-day study total.

### 6. Project
Combine robust inputs, computation and readable output.
**Exercise:** Generate a terminal learning report.

## 13. Data Analysis with Python
**Provider:** freeCodeCamp  
**Resource:** https://www.freecodecamp.org/learn/data-analysis-with-python/

Analyze structured datasets using Python libraries.

### 1. NumPy arrays
Vectorized arrays make numerical computations more concise.
**Exercise:** Compute statistics from daily study-hour values.

### 2. Pandas tables
DataFrames support filtering, grouping and data cleanup.
**Exercise:** Group learning logs by provider.

### 3. Data cleaning
Missing values and inconsistent categories distort results.
**Exercise:** Clean an intentionally messy course spreadsheet.

### 4. Descriptive statistics
Summaries such as mean and median answer different questions.
**Exercise:** Compare average versus median weekly hours.

### 5. Matplotlib
Charts reveal trends that tables can hide.
**Exercise:** Plot time spent per milestone.

### 6. Analytical project
Explain assumptions and limits alongside results.
**Exercise:** Build a report of study pace and completion.

## 14. College Algebra with Python
**Provider:** freeCodeCamp  
**Resource:** https://www.freecodecamp.org/learn/college-algebra-with-python/

Use algebraic thinking for programming, graphics, and AI.

### 1. Variables and equations
Translate relationships into expressions and solve for unknowns.
**Exercise:** Solve a learning schedule equation.

### 2. Functions and graphs
A function maps inputs to outputs and can be plotted.
**Exercise:** Graph projected cumulative learning hours.

### 3. Linear systems
Multiple equations can describe linked constraints.
**Exercise:** Solve a simple study-time allocation problem.

### 4. Exponents and logarithms
Understand exponential growth and logarithmic scales.
**Exercise:** Compare linear and exponential model behavior.

### 5. Coordinate geometry
Coordinates, vectors and distance are useful for 2D and 3D tools.
**Exercise:** Calculate distance between two cube positions.

### 6. Python practice
Confirm algebraic solutions through code and charts.
**Exercise:** Write and plot three example functions.

## 15. Information Security
**Provider:** freeCodeCamp  
**Resource:** https://www.freecodecamp.org/learn/information-security/

Understand secure software development and defensive testing.

### 1. Threat modeling
Identify what must be protected and what could go wrong.
**Exercise:** Make a threat list for a learning tracker.

### 2. Input validation
Untrusted data should never be executed or assumed safe.
**Exercise:** Reject unsafe or malformed imported JSON.

### 3. Authentication and authorization
Identity and permissions answer different questions.
**Exercise:** Model reader versus editor actions.

### 4. Secrets handling
Credentials belong outside source code and public logs.
**Exercise:** Refactor a demo to use environment configuration.

### 5. Web security foundations
Learn common injection, cross-site scripting and access-control mistakes.
**Exercise:** Audit an example form for unsafe HTML insertion.

### 6. Backup and response
A recovery strategy limits impact from accidental or malicious changes.
**Exercise:** Practice restoring a clean backup.

## 16. Machine Learning with Python
**Provider:** freeCodeCamp  
**Resource:** https://www.freecodecamp.org/learn/machine-learning-with-python/

Learn how models train, generalize and are evaluated.

### 1. Supervised learning
Models learn patterns from labeled examples.
**Exercise:** Train a simple classifier on a practice dataset.

### 2. Train and test data
Keep evaluation data separate to avoid misleading results.
**Exercise:** Partition a dataset and explain leakage.

### 3. Neural network basics
Layers learn transformations of data through optimization.
**Exercise:** Build a tiny dense neural network.

### 4. Overfitting
Training accuracy alone is not enough to prove usefulness.
**Exercise:** Compare training and validation scores.

### 5. Computer vision intro
Image models classify or locate visual features.
**Exercise:** Experiment with a small image dataset.

### 6. Evaluation project
Report strengths, weaknesses and uncertainty.
**Exercise:** Document a model card with real metrics.

## 17. AI for Beginners
**Provider:** HP LIFE  
**Resource:** https://www.life-global.org/

Understand essential AI terms and uses with no prerequisite coding.

### 1. What AI can do
AI systems infer outputs from learned patterns rather than explicit rules for every case.
**Exercise:** Identify five tasks where AI might help.

### 2. Everyday prompting
Clear requests specify a goal, constraints and expected format.
**Exercise:** Rewrite three unclear prompts.

### 3. Understanding limitations
A confident-looking answer can still be incorrect.
**Exercise:** Fact-check a sample generated answer.

### 4. Practical workflows
Decide what to delegate to AI and what to verify yourself.
**Exercise:** Plan an AI-assisted documentation task.

### 5. Portfolio exercise
Document measurable outcomes from a simple AI-assisted task.
**Exercise:** Compare a manual and AI-assisted summary.

## 18. AI Literacy
**Provider:** IBM SkillsBuild  
**Resource:** https://skillsbuild.org/digital-credentials

Develop foundational understanding of AI and its effects.

### 1. AI categories
Differentiate predictive systems, generative models and rule-based software.
**Exercise:** Match five example tasks to the right category.

### 2. Input and output
Model output depends on context and the quality of inputs.
**Exercise:** Compare short and detailed requests.

### 3. Human review
A reviewer must catch incorrect or inappropriate results.
**Exercise:** Build a three-step review checklist.

### 4. Use cases
Identify sensible uses and cases requiring extra caution.
**Exercise:** Evaluate AI for project planning versus authentication.

### 5. Reflection
Communicate what a model did and what you checked.
**Exercise:** Write a short AI-assistance disclosure.

## 19. Introduction to Generative AI
**Provider:** Google Skills  
**Resource:** https://www.skills.google/course_templates/536

Learn what generative models are and how they differ from predictive AI.

### 1. Generative models
Generation creates new outputs based on learned patterns and prompt context.
**Exercise:** Contrast a classifier with a text generator.

### 2. Modalities
Text, images and audio have different interfaces and limitations.
**Exercise:** List tools for three kinds of content.

### 3. Prompt iteration
Small prompt changes can change style and accuracy.
**Exercise:** Improve a test prompt in three iterations.

### 4. Use cases
Map model capability to a realistic business or developer task.
**Exercise:** Design an outline-generation workflow.

### 5. Evaluation
Evaluate usefulness instead of assuming polished output is correct.
**Exercise:** Create a quality rubric for responses.

## 20. Introduction to Large Language Models
**Provider:** Google Skills  
**Resource:** https://www.skills.google/course_templates/539

Understand LLM inputs, generation and tuning at a beginner level.

### 1. Tokens and context
Models process chunks of text called tokens within a bounded context window.
**Exercise:** Estimate why long prompts can lose focus.

### 2. Generation
LLMs predict likely continuations and may be wrong about facts.
**Exercise:** Compare deterministic and creative tasks.

### 3. Instruction prompts
Roles, context and examples can guide output.
**Exercise:** Create a structured bug-report prompt.

### 4. Grounding
Retrieved documents can provide evidence for answers.
**Exercise:** Draft a prompt that cites supplied documentation.

### 5. Practical use
Define expected input/output for an AI helper.
**Exercise:** Design a function-description assistant.

## 21. Getting Started with Generative AI
**Provider:** IBM SkillsBuild  
**Resource:** https://skillsbuild.org/digital-credentials

Apply generative AI to common work and creation tasks.

### 1. Core concepts
Distinguish LLMs, image models and agent systems.
**Exercise:** Classify five AI applications.

### 2. Prompt patterns
Good prompts provide role, context, format and evaluation criteria.
**Exercise:** Build a reusable code-review prompt.

### 3. Output review
Verify claims, citations and executable code rather than accepting appearances.
**Exercise:** Test generated code before use.

### 4. Workflow design
Combine AI drafting with human tests and revision loops.
**Exercise:** Outline an AI-assisted feature process.

### 5. Small project
Demonstrate repeatable productivity without overstating automation.
**Exercise:** Produce and review a technical README.

## 22. Prompt Fundamentals
**Provider:** Salesforce Trailhead  
**Resource:** https://trailhead.salesforce.com/content/learn/modules/prompt-fundamentals

Write better instructions and understand prompt templates.

### 1. Prompt anatomy
A useful instruction defines task, input context and output shape.
**Exercise:** Create a prompt template for bug triage.

### 2. Few-shot examples
Examples illustrate the target output format.
**Exercise:** Give an AI assistant two example issue summaries.

### 3. Structured outputs
JSON and tables are useful when another tool consumes the result.
**Exercise:** Request and validate a JSON response.

### 4. Iteration
Compare outputs and revise one variable at a time.
**Exercise:** Run three versions of a summarization prompt.

### 5. Quality checklist
Test prompts against ambiguous or missing information.
**Exercise:** Make a prompt acceptance rubric.

## 23. Craft Precise Prompts for AI Models
**Provider:** IBM SkillsBuild  
**Resource:** https://skillsbuild.org/digital-credentials

Create reusable prompts for precise, repeatable AI assistance.

### 1. Goal definition
Decide what success looks like before choosing prompt wording.
**Exercise:** Define exact acceptance criteria for a code patch.

### 2. Context packaging
Supply only relevant files, interfaces and constraints.
**Exercise:** Write a compact task context block.

### 3. Output contracts
Specify format, naming and validation requirements.
**Exercise:** Ask for patch notes plus a test plan.

### 4. Prompt debugging
Identify why a response missed a requirement and adjust the prompt.
**Exercise:** Compare before and after prompts.

### 5. Prompt library
Save reusable prompts as versioned project assets.
**Exercise:** Build five prompts for your own workflow.

## 24. Generative AI Essentials: Using LLMs to Work with Data
**Provider:** IBM SkillsBuild  
**Resource:** https://skillsbuild.org/digital-credentials

Use LLMs to organize, summarize and analyze information.

### 1. Structured data
Understand rows, columns, schemas and common data formats.
**Exercise:** Inspect a small progress CSV.

### 2. Extraction
Request well-defined fields from unstructured text.
**Exercise:** Extract milestones from a sample meeting note.

### 3. Summarization
Summaries should retain key facts without inventing information.
**Exercise:** Compare an AI summary against its source.

### 4. Validation
Verify calculations and outputs independently.
**Exercise:** Check computed completion rates in Python.

### 5. Workflow
Build a small input-transform-verify-report pipeline.
**Exercise:** Document a learning-report prototype.

## 25. Introduction to Responsible AI
**Provider:** Google Skills  
**Resource:** https://www.skills.google/course_templates/554

Recognize bias, security, privacy and reliability issues.

### 1. Fairness and bias
AI systems can reproduce patterns that disadvantage some groups.
**Exercise:** Analyze an example of skewed training data.

### 2. Privacy
Avoid using sensitive records without clear permission and safeguards.
**Exercise:** Create a data-sharing decision checklist.

### 3. Transparency
Explain where AI assisted and what remains uncertain.
**Exercise:** Write a model-use note for a portfolio project.

### 4. Safety controls
Human review and validation reduce preventable errors.
**Exercise:** Add confirmation before an automated deletion step.

### 5. Governance
Record goals, limitations and tests for important systems.
**Exercise:** Draft a one-page responsible-use policy.

## 26. Introduction to Modern AI
**Provider:** Cisco Networking Academy  
**Resource:** https://www.netacad.com/

Survey AI capabilities, prompting and responsible collaboration.

### 1. AI landscape
Understand major families of modern AI systems.
**Exercise:** Create a tool comparison chart.

### 2. Productivity use
Apply AI to research, drafting and code assistance with review.
**Exercise:** Build a supervised documentation workflow.

### 3. Prompt skills
Specify clear context and test generated responses.
**Exercise:** Produce three versions of a coding task prompt.

### 4. Limitations
Evaluate output quality, provenance and security concerns.
**Exercise:** Flag unverified claims in an example output.

### 5. Practical plan
Choose realistic next skills and tools.
**Exercise:** Design your next 30-day learning sprint.

## 27. Agentforce Basics
**Provider:** Salesforce Trailhead  
**Resource:** https://trailhead.salesforce.com/

Understand how software agents interact with tasks and business data.

### 1. Agent roles
Agents coordinate model decisions with defined tasks.
**Exercise:** Define a customer-support agent goal.

### 2. Knowledge sources
Agents need authorized, relevant information.
**Exercise:** List the documents an agent should consult.

### 3. Actions and permissions
A tool action is different from a generated suggestion.
**Exercise:** Decide which actions require confirmation.

### 4. Testing
Evaluate agent behavior with scenarios and failure cases.
**Exercise:** Design five agent test conversations.

### 5. Prototype
Outline a narrowly scoped information assistant.
**Exercise:** Build a mock workflow diagram.

## 28. Make Agentic AI Work for You
**Provider:** IBM SkillsBuild  
**Resource:** https://skillsbuild.org/digital-credentials

Learn planning, RAG, tool use and multi-step agent workflows.

### 1. Agent loops
An agent observes, selects an action, executes it and evaluates the result.
**Exercise:** Draw an observe-act-check loop.

### 2. Tool calling
Tools expose defined operations and input schemas.
**Exercise:** Specify a read-only file-search tool.

### 3. Retrieval-augmented generation
RAG retrieves context before generating an answer.
**Exercise:** Design a Q&A flow for a small manual.

### 4. Multi-agent patterns
Several specialized agents can coordinate through explicit handoffs.
**Exercise:** Create planner, coder and tester roles.

### 5. Safeguards
Timeouts, budgets and confirmation gates constrain risky behavior.
**Exercise:** Add an approval step before file deletion.

## 29. AI Agents Fundamentals
**Provider:** Hugging Face  
**Resource:** https://huggingface.co/learn/agents-course/en/unit0/introduction

Learn the core structures behind AI agents and external tools.

### 1. Model and environment
Distinguish a language model from the program that runs tools and maintains state.
**Exercise:** Sketch a minimal agent architecture.

### 2. Tools
Define tool names, arguments, descriptions and results.
**Exercise:** Write a file-listing tool schema.

### 3. Agent frameworks
Compare framework concepts without assuming one is necessary.
**Exercise:** Build a simple agent without a framework.

### 4. Control flow
Avoid unbounded loops by setting clear stop conditions.
**Exercise:** Add a step budget to a mock agent.

### 5. Fundamentals challenge
Apply the basic concepts to a small demonstrable task.
**Exercise:** Build a tool-using calculator assistant.

## 30. AI Agents Course Completion
**Provider:** Hugging Face  
**Resource:** https://huggingface.co/learn/agents-course/en/unit0/introduction

Practice more advanced agent development and the final challenges.

### 1. Advanced tool integration
Connect multiple well-specified tools and handle their outputs.
**Exercise:** Design a search-then-summarize agent.

### 2. State and memory
Durable state must be represented explicitly rather than assumed.
**Exercise:** Persist short agent task history in JSON.

### 3. Evaluation
Score tool success, factuality and completion on known tasks.
**Exercise:** Create a ten-case evaluation set.

### 4. Robustness
Recover from network errors, empty results and tool exceptions.
**Exercise:** Simulate three failure conditions.

### 5. Final challenge
Demonstrate measurable agent performance in a reproducible project.
**Exercise:** Package code, tests and a walkthrough.

## 31. Get Started Developing Agents in Microsoft Foundry
**Provider:** Microsoft Learn  
**Resource:** https://learn.microsoft.com/en-us/credentials/applied-skills/get-started-developing-agents-in-microsoft-foundry/

Create and test AI agents using Microsoft development services.

### 1. Project setup
Set up a service project and inspect the platform tools available.
**Exercise:** Diagram the required components and costs.

### 2. Model deployment
Deployment makes a model available to applications.
**Exercise:** Configure a test deployment in a permitted environment.

### 3. Agent configuration
Instructions and tool access define behavior.
**Exercise:** Create an agent that answers documentation questions.

### 4. Testing
Compare outputs against expected prompts and safety boundaries.
**Exercise:** Run a five-case evaluation sheet.

### 5. Assessment readiness
Review task workflows and reproduce them reliably.
**Exercise:** Practice a complete setup-test-cleanup cycle.

## 32. Accelerate App Development with GitHub Copilot
**Provider:** Microsoft Learn  
**Resource:** https://learn.microsoft.com/en-us/credentials/applied-skills/accelerate-app-development-by-using-github-copilot/

Use an AI coding assistant to implement, refactor and test software.

### 1. Editor workflow
Learn how assistant suggestions relate to your open files and workspace.
**Exercise:** Complete a small guided edit in VS Code.

### 2. Prompting for code
Give precise requirements, constraints and existing APIs.
**Exercise:** Ask for a small function with tests.

### 3. Debugging with AI
Share reproducible errors and verify every proposed fix.
**Exercise:** Fix one failing unit test using AI assistance.

### 4. Refactoring
Improve code structure while keeping externally visible behavior stable.
**Exercise:** Refactor a long function and rerun tests.

### 5. Quality checks
Review diffs, run tests and document accepted changes.
**Exercise:** Produce a code review checklist for an AI-generated patch.

### 6. Project evidence
Show actual changes and outcome rather than just AI prompts.
**Exercise:** Publish a PR with explanation and passing tests.

## 33. Introduction to Agentforce Builder
**Provider:** Salesforce Trailhead  
**Resource:** https://trailhead.salesforce.com/

Configure agent behavior and evaluate tool-assisted flows.

### 1. Agent configuration
Define narrow topics, instructions, and expected outcomes.
**Exercise:** Plan an agent for answering common learning questions.

### 2. Actions
Connect agent decisions to permissioned operations.
**Exercise:** Specify a safe add-note action.

### 3. Knowledge grounding
Give the assistant authoritative source data when appropriate.
**Exercise:** Design document retrieval for lesson notes.

### 4. Testing and refinement
Test incomplete requests, incorrect assumptions and interruptions.
**Exercise:** Revise the agent from a test log.

### 5. Deployment controls
Review visibility, human approvals and change management.
**Exercise:** Draft a pre-release checklist.

# Forge Operations Manual

## 1. Welcome and the learning map
The Forge has 33 milestone cubes, grouped in five phases. You can select a cube, read its outline and open it to explore smaller lesson cubes. Start with freeCodeCamp #1 and work forward. Lesson outlines in this app are study aids, not copied official course curricula.
**Exercise:** Select milestone #1, then open its lesson cubes.

## 2. Orbit, zoom and navigate the 3D world
Drag the 3D canvas to orbit. Use the scroll wheel or the + and – buttons to zoom. On touchscreens, drag with one finger and use two fingers to zoom. Select a cube by clicking or tapping it. The left milestone list is a fully usable alternative to 3D selection.
**Exercise:** Rotate the scene, zoom in, select cube #1 and return to the map.

## 3. Enter a milestone and open lessons
The main map shows milestone cubes. Press Open Cube to enter a milestone and see its smaller lesson cubes. Selecting a lesson opens its explanation, exercise, progress toggle and notes editor in the inspector.
**Exercise:** Open any milestone, select its second lesson and mark it in progress by adding a note.

## 4. Use notes and completed checkmarks
Each milestone and lesson has separate editable notes. Notes save automatically into this browser’s local storage. Tick Finished only after you have completed the lesson or assessment and verified the result. Your progress percentages are derived from lesson checkmarks.
**Exercise:** Add one fact you learned to a lesson note, then mark that lesson complete.

## 5. Add custom sections and project steps
The catalog starts with a six-or-five-step breakdown per milestone, but you can create your own lessons using Add Lesson. Every custom lesson is searchable and has its own notes and completion state. You can also add custom milestone cubes.
**Exercise:** Add a custom lesson named First Portfolio Demo to a milestone.

## 6. Use the daily learning journal
A learning journal is a chronological record of what you tried, what worked, what failed and what you will do next. The journal lives in this Forge and is included in backups. Prefer specific entries such as Finished CSS Grid exercise; still confused about minmax().
**Exercise:** Add a journal entry documenting your first session.

## 7. Export and import safely
The Forge stores progress in this browser, not automatically in ChatGPT or a cloud account. Export Backup creates a portable JSON file containing lesson notes, journal entries, status and custom cubes. Export Markdown creates readable notes. Import Backup restores the JSON on another computer or browser. Keep copies of the JSON file.
**Exercise:** Export a JSON backup and confirm that you can see the downloaded file.

## 8. Code Forge workflow: inspect, plan, edit, test
For the HEAVEN code forge, use a safe repeatable editing loop: inspect a file, define one change, save a copy or commit, edit the smallest relevant code, run the project, reproduce the result and record what changed. This is a general engineering workflow; actual HEAVEN control mappings will be added when its Forge source is available.
**Exercise:** Describe one HEAVEN bug with steps to reproduce, expected behavior and actual behavior.

## 9. Code Forge workflow: versions and rollback
Never treat one edited copy as your only working version. Record a known-good baseline, make isolated changes, compare the old and new behavior, and keep a way to roll back. AI-generated patches still need manual review and tests.
**Exercise:** Write a rollback plan for a hypothetical broken rendering patch.

## 10. Future integration with the game Forge
This learning app is self-contained and does not alter the HEAVEN game. The long-term integration point is a shared JSON schema for phases, cubes, lessons, notes and progress. After the actual in-game Code Cube Forge source is supplied, its navigation, materials and behavior can be matched precisely.
**Exercise:** Write down the three original Code Forge controls you want documented first.
