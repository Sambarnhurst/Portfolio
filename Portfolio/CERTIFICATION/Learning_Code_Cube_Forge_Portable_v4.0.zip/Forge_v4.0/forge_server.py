#!/usr/bin/env python3
"""Learning Code Cube Forge — localhost-only source workspace. Python 3.10+; no dependencies."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import re
import secrets
import shutil
import sys
import tempfile
import time
import webbrowser
from datetime import datetime, timezone
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

APP_DIR = Path(__file__).resolve().parent
TEXT_EXTENSIONS = {
    '.html', '.htm', '.css', '.js', '.jsx', '.mjs', '.cjs', '.ts', '.tsx', '.py', '.json',
    '.md', '.txt', '.yml', '.yaml', '.xml', '.vue', '.svelte', '.sql', '.sh', '.bat',
    '.ps1', '.cmd', '.cs', '.cpp', '.c', '.h', '.hpp', '.java', '.go', '.rs', '.php',
    '.toml', '.ini', '.cfg', '.glsl', '.vert', '.frag', '.shader', '.gitignore',
    '.dockerignore', '.svg', '.gd', '.lua', '.rb', '.swift', '.kt', '.lock', '.gradle'
}
TEXT_NAMES = {'Dockerfile','Makefile','LICENSE','.gitignore','.dockerignore','.editorconfig','CMakeLists.txt'}
HIDDEN_DIRS = {'.git', 'node_modules', '.venv', 'venv', '__pycache__', '.forge_backups', '.next', 'dist', 'build', '.cache'}
MAX_READ = 2_000_000
MAX_WRITE = 2_000_000

parser = argparse.ArgumentParser(description='Run an editable local Code Cube Forge.')
parser.add_argument('--project', default=str(APP_DIR), help='Absolute or relative directory to browse/edit (defaults to Forge folder)')
parser.add_argument('--port', type=int, default=8797)
parser.add_argument('--no-browser', action='store_true', help='Print URL without opening browser')
args = parser.parse_args()
ROOT = Path(args.project).expanduser().resolve()
if not ROOT.is_dir():
    parser.error(f'Project folder not found: {ROOT}')
TOKEN = secrets.token_urlsafe(32)
ACTIVE_PORT = args.port
BACKUPS = ROOT / '.forge_backups'


def approved_path(raw, allow_root=True):
    if not isinstance(raw, str) or '\\' in raw or '\x00' in raw or raw.startswith('/') or re.match(r'^[A-Za-z]:', raw):
        raise ValueError('Invalid project-relative path')
    parts = Path(raw).parts
    if any(p in ('..', '.') or p in HIDDEN_DIRS for p in parts):
        raise ValueError('Path outside editable project scope')
    rel = Path(*parts)
    result = ROOT / rel
    if not allow_root and result == ROOT:
        raise ValueError('Select a file or folder')
    if not result.resolve(strict=False).is_relative_to(ROOT):
        raise ValueError('Path escapes project root')
    # Block symlink traversal even when target is inside ROOT.
    current = ROOT
    for part in rel.parts:
        current /= part
        if current.is_symlink():
            raise ValueError('Symlinks are not editable through the Forge')
    return result


def rel(p):
    return p.relative_to(ROOT).as_posix()


def editable(p):
    return p.suffix.lower() in TEXT_EXTENSIONS or p.name in TEXT_NAMES


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_file(path):
    if not path.is_file() or not editable(path):
        raise ValueError('Not an editable text file')
    if path.stat().st_size > MAX_READ:
        raise ValueError('File exceeds 2 MB editor limit')
    data = path.read_bytes()
    if b'\x00' in data:
        raise ValueError('Binary files cannot be opened in source editor')
    try:
        return data.decode('utf-8'), digest(data)
    except UnicodeDecodeError:
        raise ValueError('Text is not valid UTF-8; convert before editing')


def backup(path, data):
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    dest = BACKUPS / 'history' / path.relative_to(ROOT).parent / (path.name + '.' + stamp + '.bak')
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    return rel(dest)


def atomic_write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_name = None
    try:
        with tempfile.NamedTemporaryFile(mode='wb', dir=path.parent, prefix='.forge_tmp_', delete=False) as f:
            temp_name = f.name
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp_name, path)
    finally:
        if temp_name and os.path.exists(temp_name):
            os.unlink(temp_name)


class ForgeHandler(BaseHTTPRequestHandler):
    server_version = 'LearningCodeForge/3.0'

    def reply(self, code, payload):
        body = json.dumps(payload, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _require_token(self):
        if self.headers.get('X-Forge-Token') != TOKEN:
            raise PermissionError('Open the URL printed by the Forge launcher to authenticate')
        origin = self.headers.get('Origin')
        if origin:
            expected = f'http://127.0.0.1:{ACTIVE_PORT}'
            if origin != expected:
                raise PermissionError('Cross-origin requests are not allowed')

    def _read_json(self):
        sz = int(self.headers.get('Content-Length','0'))
        if sz <= 0 or sz > MAX_WRITE + 2048:
            raise ValueError('Invalid request size')
        payload = json.loads(self.rfile.read(sz).decode('utf-8'))
        if not isinstance(payload,dict):
            raise ValueError('Expected JSON object')
        return payload

    def handle_api(self, is_post=False):
        self._require_token()
        url = urlsplit(self.path)
        qs = parse_qs(url.query)
        get = lambda name,default='': qs.get(name,[default])[0]
        data = self._read_json() if is_post else {}
        op = url.path
        if not is_post and op == '/api/status':
            return {'ok':True,'project':str(ROOT),'mode':'local-disk','maxBytes':MAX_READ}
        if not is_post and op == '/api/list':
            d = approved_path(get('path'))
            if not d.is_dir(): raise ValueError('Not a folder')
            result=[]
            for entry in sorted(d.iterdir(),key=lambda p:(not p.is_dir(),p.name.lower())):
                if entry.name in HIDDEN_DIRS or entry.is_symlink(): continue
                if entry.name.startswith('.') and entry.name not in TEXT_NAMES: continue
                try:
                    st=entry.stat()
                    result.append({'path':rel(entry),'name':entry.name,'type':'folder' if entry.is_dir() else 'file','size':st.st_size if entry.is_file() else 0,'editable':editable(entry) if entry.is_file() else True,'modified':st.st_mtime})
                except (PermissionError,OSError): pass
            return {'items':result[:1500], 'truncated':len(result)>1500,'folder':rel(d)}
        if not is_post and op == '/api/read':
            path=approved_path(get('path'),False)
            source,h=read_file(path)
            return {'path':rel(path),'content':source,'hash':h}
        if not is_post and op == '/api/history':
            p=approved_path(get('path'),False)
            folder=BACKUPS / 'history' / p.relative_to(ROOT).parent
            prefix=p.name+'.'
            entries=[]
            if folder.is_dir():
                for f in sorted(folder.iterdir(),reverse=True):
                    if f.name.startswith(prefix) and f.name.endswith('.bak'):
                        entries.append({'id':f.name, 'timestamp':f.stat().st_mtime,'size':f.stat().st_size})
            return {'entries':entries[:50]}
        if is_post and op == '/api/write':
            p=approved_path(data.get('path',''),False)
            if not p.is_file(): raise ValueError('File not found; use New file')
            if not editable(p): raise ValueError('Only text source files may be edited')
            content=data.get('content')
            if not isinstance(content,str): raise ValueError('Invalid editor text')
            raw=content.encode('utf-8')
            if len(raw)>MAX_WRITE: raise ValueError('File exceeds 2 MB limit')
            current=p.read_bytes()
            expected=data.get('expectedHash')
            if expected != digest(current):
                return {'ok':False,'conflict':True,'error':'File changed on disk; reload before overwriting'}
            b=backup(p,current)
            atomic_write(p,raw)
            return {'ok':True,'hash':digest(raw),'backup':b}
        if is_post and op == '/api/create':
            p=approved_path(data.get('path',''),False)
            if p.exists(): raise ValueError('File already exists')
            if not editable(p): raise ValueError('Use a supported source-code extension')
            source=data.get('content','')
            if not isinstance(source,str) or len(source.encode('utf-8'))>MAX_WRITE: raise ValueError('Invalid file content')
            atomic_write(p,source.encode('utf-8'))
            return {'ok':True,'path':rel(p)}
        if is_post and op == '/api/mkdir':
            p=approved_path(data.get('path',''),False)
            p.mkdir(parents=False, exist_ok=False)
            return {'ok':True,'path':rel(p)}
        if is_post and op == '/api/rename':
            src=approved_path(data.get('path',''),False)
            dest=approved_path(data.get('newPath',''),False)
            if not src.exists() or dest.exists() or not dest.parent.exists(): raise ValueError('Invalid rename or destination already exists')
            if src.is_file() and not editable(dest): raise ValueError('New filename must remain an editable source type')
            src.rename(dest)
            return {'ok':True,'path':rel(dest)}
        if is_post and op == '/api/delete':
            src=approved_path(data.get('path',''),False)
            if src.is_dir():
                if any(src.iterdir()): raise ValueError('Remove the folder contents first')
                src.rmdir()
            elif src.is_file():
                stamp=str(int(time.time()*1000))
                dest=BACKUPS/'trash'/stamp/src.relative_to(ROOT)
                dest.parent.mkdir(parents=True,exist_ok=True)
                shutil.move(str(src),str(dest))
            else: raise ValueError('File not found')
            return {'ok':True}
        if is_post and op == '/api/restore':
            p=approved_path(data.get('path',''),False)
            name=data.get('id','')
            if not isinstance(name,str) or '/' in name or '\\' in name or not name.startswith(p.name+'.') or not name.endswith('.bak'):
                raise ValueError('Invalid backup identifier')
            src=BACKUPS/'history'/p.relative_to(ROOT).parent/name
            if not src.is_file(): raise ValueError('Backup not found')
            content=src.read_bytes()
            if p.exists(): backup(p,p.read_bytes())
            atomic_write(p,content)
            return {'ok':True,'hash':digest(content)}
        raise ValueError('Unknown API action')

    def do_GET(self):
        try:
            u=urlsplit(self.path)
            if u.path.startswith('/api/'):
                return self.reply(200,self.handle_api(False))
            if u.path in ('/','/index.html'):
                b=(APP_DIR/'index.html').read_bytes()
                self.send_response(200)
                self.send_header('Content-Type','text/html; charset=utf-8')
                self.send_header('Cache-Control','no-store')
                self.send_header('Content-Length',str(len(b)))
                self.end_headers();self.wfile.write(b)
                return
            self.reply(404,{'error':'Not found'})
        except PermissionError as e: self.reply(403,{'error':str(e)})
        except (ValueError,OSError,UnicodeError,json.JSONDecodeError) as e: self.reply(400,{'error':str(e)})

    def do_POST(self):
        try:
            return self.reply(200,self.handle_api(True))
        except PermissionError as e: self.reply(403,{'error':str(e)})
        except (ValueError,OSError,UnicodeError,json.JSONDecodeError) as e: self.reply(400,{'error':str(e)})

    def log_message(self, format, *args):
        print(f'[{self.log_date_time_string()}] {format%args}')

if __name__ == '__main__':
    server = None
    for p in range(args.port,args.port+30):
        try:
            server=ThreadingHTTPServer(('127.0.0.1',p),ForgeHandler)
            ACTIVE_PORT=p
            break
        except OSError:
            continue
    if server is None:
        sys.exit('No free local port found. Choose another with --port.')
    if ACTIVE_PORT!=args.port: print(f'Port {args.port} was occupied; using {ACTIVE_PORT} instead.',flush=True)
    print('\nLEARNING CODE CUBE FORGE 3.0 — LOCAL SOURCE EDITOR',flush=True)
    print('Project folder: '+str(ROOT),flush=True)
    print('Open this private local URL:\n',f'http://127.0.0.1:{ACTIVE_PORT}/?key={TOKEN}', '\n',flush=True)
    print('No remote network access. CTRL+C stops this server. Existing files are backed up before saving.\n',flush=True)
    if not args.no_browser:
        try:webbrowser.open(f'http://127.0.0.1:{ACTIVE_PORT}/?key={TOKEN}')
        except Exception:pass
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close()
