@echo off
setlocal
cd /d "%~dp0"
set "PROJECT=%CD%"
if not "%~1"=="" set "PROJECT=%~1"
where python >nul 2>&1
if %errorlevel%==0 (
  python forge_server.py --project "%PROJECT%"
) else (
  where py >nul 2>&1
  if %errorlevel%==0 (
    py -3 forge_server.py --project "%PROJECT%"
  ) else (
    echo Python 3.10 or newer is required. Install Python and relaunch.
    pause
  )
)
endlocal
